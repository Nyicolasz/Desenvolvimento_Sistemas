/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.controle_caixa;

/**
 *
 * @author Admin
 */
public class ConversorNumeros {
    public Integer stringToInt(String num){
        int conversor = Integer.parseInt(num);
        return(conversor);
    }
    public Double stringToDouble(String num){
        double conversor = Double.parseDouble(num);
        return (conversor);
    }
}
