/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.controle_caixa;

/**
 *
 * @author Admin
 */
public class Principal {
    public static void main(String[] args){
        Menu menuPrincipal = new Menu();
        menuPrincipal.executarCaixa();
    }
}
